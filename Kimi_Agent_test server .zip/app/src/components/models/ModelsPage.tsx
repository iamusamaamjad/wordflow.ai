import { useState, useEffect } from 'react';
import { 
  Volume2, 
  Brain, 
  Check, 
  AlertCircle,
  ChevronDown,
  Mic
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

interface Voice {
  id: string;
  name: string;
  gender?: string;
}

interface VoiceModel {
  id: string;
  name: string;
  voices: Voice[];
}

interface LLMModel {
  id: string;
  name: string;
  provider: string;
}

const LLM_MODELS: LLMModel[] = [
  { id: 'gpt-3.5-turbo', name: 'GPT-3.5 Turbo', provider: 'OpenAI' },
  { id: 'gpt-4', name: 'GPT-4', provider: 'OpenAI' },
  { id: 'gpt-4-turbo', name: 'GPT-4 Turbo', provider: 'OpenAI' },
];

const VOICE_MODELS: VoiceModel[] = [
  {
    id: 'openai-tts',
    name: 'OpenAI TTS',
    voices: [
      { id: 'alloy', name: 'Alloy', gender: 'Neutral' },
      { id: 'echo', name: 'Echo', gender: 'Male' },
      { id: 'fable', name: 'Fable', gender: 'Male' },
      { id: 'onyx', name: 'Onyx', gender: 'Male' },
      { id: 'nova', name: 'Nova', gender: 'Female' },
      { id: 'shimmer', name: 'Shimmer', gender: 'Female' },
    ]
  },
  {
    id: 'browser-tts',
    name: 'Browser TTS',
    voices: [
      { id: 'default-male', name: 'Default Male', gender: 'Male' },
      { id: 'default-female', name: 'Default Female', gender: 'Female' },
      { id: 'default-neutral', name: 'Default Neutral', gender: 'Neutral' },
    ]
  }
];

interface ModelsPageProps {
  apiKey: string;
}

export function ModelsPage({ apiKey }: ModelsPageProps) {
  const [selectedLLM, setSelectedLLM] = useState('gpt-3.5-turbo');
  const [selectedVoiceModel, setSelectedVoiceModel] = useState('openai-tts');
  const [selectedVoice, setSelectedVoice] = useState('nova');
  const [isSaved, setIsSaved] = useState(false);

  // Load saved settings
  useEffect(() => {
    const savedLLM = localStorage.getItem('workflow_llm_model');
    const savedVoiceModel = localStorage.getItem('workflow_voice_model');
    const savedVoice = localStorage.getItem('workflow_voice_id');

    if (savedLLM) setSelectedLLM(savedLLM);
    if (savedVoiceModel) setSelectedVoiceModel(savedVoiceModel);
    if (savedVoice) setSelectedVoice(savedVoice);
  }, []);

  const saveSettings = () => {
    localStorage.setItem('workflow_llm_model', selectedLLM);
    localStorage.setItem('workflow_voice_model', selectedVoiceModel);
    localStorage.setItem('workflow_voice_id', selectedVoice);
    
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  const previewVoice = () => {
    const utterance = new SpeechSynthesisUtterance('Hello! This is how I sound.');
    
    const voices = window.speechSynthesis.getVoices();
    const voice = voices.find(v => v.name.toLowerCase().includes(selectedVoice.toLowerCase()));
    if (voice) utterance.voice = voice;
    
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utterance);
  };

  const currentVoiceModel = VOICE_MODELS.find(m => m.id === selectedVoiceModel);
  const availableVoices = currentVoiceModel?.voices || [];

  return (
    <div className="flex-1 bg-black p-8 overflow-auto">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-white">Models</h1>
          <Button 
            onClick={saveSettings}
            className={`transition-all ${isSaved ? 'bg-emerald-500 hover:bg-emerald-600' : 'bg-white text-black hover:bg-gray-100'}`}
          >
            {isSaved ? (
              <>
                <Check className="w-4 h-4 mr-2" />
                Saved
              </>
            ) : (
              'Save Changes'
            )}
          </Button>
        </div>

        {/* Language Model */}
        <Card className="bg-[#111111] border-[#222222] p-5 mb-4">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center">
              <Brain className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <h2 className="text-white font-semibold">Language Model</h2>
              <p className="text-gray-500 text-sm">Select the AI model for conversations</p>
            </div>
          </div>

          <div className="relative">
            <select
              value={selectedLLM}
              onChange={(e) => setSelectedLLM(e.target.value)}
              className="w-full bg-[#1a1a1a] border border-[#333333] rounded-lg px-4 py-3 text-white text-sm appearance-none cursor-pointer focus:outline-none focus:border-purple-500/50"
            >
              {LLM_MODELS.map((model) => (
                <option key={model.id} value={model.id}>
                  {model.name}
                </option>
              ))}
            </select>
            <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500 pointer-events-none" />
          </div>
        </Card>

        {/* Voice Model */}
        <Card className="bg-[#111111] border-[#222222] p-5 mb-4">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
              <Mic className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <h2 className="text-white font-semibold">Voice Model</h2>
              <p className="text-gray-500 text-sm">Select the voice synthesis provider</p>
            </div>
          </div>

          <div className="relative">
            <select
              value={selectedVoiceModel}
              onChange={(e) => {
                setSelectedVoiceModel(e.target.value);
                const newModel = VOICE_MODELS.find(m => m.id === e.target.value);
                if (newModel && newModel.voices.length > 0) {
                  setSelectedVoice(newModel.voices[0].id);
                }
              }}
              className="w-full bg-[#1a1a1a] border border-[#333333] rounded-lg px-4 py-3 text-white text-sm appearance-none cursor-pointer focus:outline-none focus:border-blue-500/50"
            >
              {VOICE_MODELS.map((model) => (
                <option key={model.id} value={model.id}>
                  {model.name}
                </option>
              ))}
            </select>
            <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500 pointer-events-none" />
          </div>
        </Card>

        {/* Voice */}
        <Card className="bg-[#111111] border-[#222222] p-5 mb-4">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-lg bg-emerald-500/20 flex items-center justify-center">
              <Volume2 className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h2 className="text-white font-semibold">Voice</h2>
              <p className="text-gray-500 text-sm">Select the voice for AI responses</p>
            </div>
          </div>

          {!apiKey && selectedVoiceModel === 'openai-tts' && (
            <div className="mb-3 p-3 bg-amber-500/10 border border-amber-500/30 rounded-lg flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-amber-400 flex-shrink-0" />
              <span className="text-amber-400 text-sm">Add your OpenAI API key to use OpenAI TTS voices</span>
            </div>
          )}

          <div className="relative">
            <select
              value={selectedVoice}
              onChange={(e) => setSelectedVoice(e.target.value)}
              className="w-full bg-[#1a1a1a] border border-[#333333] rounded-lg px-4 py-3 text-white text-sm appearance-none cursor-pointer focus:outline-none focus:border-emerald-500/50"
            >
              {availableVoices.map((voice) => (
                <option key={voice.id} value={voice.id}>
                  {voice.name} {voice.gender ? `(${voice.gender})` : ''}
                </option>
              ))}
            </select>
            <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500 pointer-events-none" />
          </div>

          <Button
            variant="outline"
            onClick={previewVoice}
            className="mt-3 border-[#333333] text-gray-300 hover:bg-[#1a1a1a]"
          >
            <Volume2 className="w-4 h-4 mr-2" />
            Preview Voice
          </Button>
        </Card>

        {/* Current Configuration */}
        <Card className="bg-[#0f0f0f] border-[#222222] p-4">
          <h3 className="text-gray-400 text-sm font-medium mb-3">Current Configuration</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-500">Language Model:</span>
              <span className="text-white">
                {LLM_MODELS.find(m => m.id === selectedLLM)?.name}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">Voice Model:</span>
              <span className="text-white">
                {VOICE_MODELS.find(m => m.id === selectedVoiceModel)?.name}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">Voice:</span>
              <span className="text-white">
                {availableVoices.find(v => v.id === selectedVoice)?.name}
              </span>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
