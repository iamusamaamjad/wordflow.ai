import { useEffect, useRef } from 'react';
import { PhoneCall, PhoneOff, Mic, MicOff, Volume2, VolumeX, Loader2, AlertCircle, Check, Key } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import type { CallStatus } from '@/types';

interface CallPanelProps {
  callStatus: CallStatus;
  isListening: boolean;
  isSpeaking: boolean;
  isAILoading: boolean;
  isMuted: boolean;
  isConfigured: boolean;
  interimTranscript: string;
  error: string | null;
  onStartCall: () => void;
  onEndCall: () => void;
  onToggleMute: () => void;
  onToggleListening: () => void;
  onOpenSettings: () => void;
}

export function CallPanel({
  callStatus,
  isListening,
  isSpeaking,
  isAILoading,
  isMuted,
  isConfigured,
  interimTranscript,
  error,
  onStartCall,
  onEndCall,
  onToggleMute,
  onToggleListening,
  onOpenSettings
}: CallPanelProps) {
  return (
    <div className="flex-1 flex flex-col items-center justify-center bg-black p-6">
      <Card className="bg-[#111111] border-[#222222] w-full max-w-md p-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-white text-lg font-medium">AI Voice Agent</h2>
          <StatusBadge isConfigured={isConfigured} callStatus={callStatus} />
        </div>

        {/* Error Display */}
        {error && callStatus !== 'idle' && (
          <div className="mb-4 p-3 bg-red-500/10 border border-red-500/30 rounded-lg">
            <div className="flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
              <p className="text-red-400 text-sm">{error}</p>
            </div>
          </div>
        )}

        {/* Status Text */}
        <StatusText 
          isSpeaking={isSpeaking} 
          isListening={isListening} 
          isAILoading={isAILoading}
          callStatus={callStatus}
        />

        {/* Main Content */}
        <div className="flex flex-col items-center py-6">
          {callStatus === 'idle' && (
            <IdleState 
              isConfigured={isConfigured} 
              onStartCall={onStartCall}
              onOpenSettings={onOpenSettings}
            />
          )}

          {callStatus === 'connecting' && <ConnectingState />}

          {callStatus === 'connected' && (
            <ConnectedState
              isSpeaking={isSpeaking}
              isListening={isListening}
              isMuted={isMuted}
              isAILoading={isAILoading}
              interimTranscript={interimTranscript}
              onToggleMute={onToggleMute}
              onEndCall={onEndCall}
              onToggleListening={onToggleListening}
            />
          )}

          {callStatus === 'ended' && <EndedState />}
        </div>
      </Card>

      {/* Tips */}
      {callStatus === 'idle' && isConfigured && (
        <p className="mt-4 text-gray-500 text-sm text-center">
          Click Start Call and speak naturally. The AI will respond to your voice.
        </p>
      )}
    </div>
  );
}

function StatusBadge({ isConfigured, callStatus }: { isConfigured: boolean; callStatus: CallStatus }) {
  if (callStatus === 'connected') {
    return (
      <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
        <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 mr-1.5 animate-pulse" />
        Live
      </Badge>
    );
  }
  
  if (!isConfigured) {
    return (
      <Badge variant="outline" className="text-amber-400 border-amber-500/30 bg-amber-500/10">
        <AlertCircle className="w-3 h-3 mr-1" />
        Setup Required
      </Badge>
    );
  }

  return (
    <Badge variant="outline" className="text-emerald-400 border-emerald-500/30 bg-emerald-500/10">
      <Check className="w-3 h-3 mr-1" />
      Ready
    </Badge>
  );
}

function StatusText({ isSpeaking, isListening, isAILoading, callStatus }: {
  isSpeaking: boolean;
  isListening: boolean;
  isAILoading: boolean;
  callStatus: CallStatus;
}) {
  if (callStatus !== 'connected') return null;

  return (
    <div className="h-6 flex items-center justify-center mb-4">
      {isSpeaking && (
        <div className="flex items-center gap-2 text-emerald-400 text-sm animate-fade-in">
          <Volume2 className="w-4 h-4" />
          <span>Agent is speaking...</span>
        </div>
      )}
      {isListening && !isSpeaking && (
        <div className="flex items-center gap-2 text-blue-400 text-sm animate-fade-in">
          <Mic className="w-4 h-4" />
          <span>Listening to you...</span>
        </div>
      )}
      {isAILoading && !isSpeaking && (
        <div className="flex items-center gap-2 text-purple-400 text-sm animate-fade-in">
          <Loader2 className="w-4 h-4 animate-spin" />
          <span>AI is thinking...</span>
        </div>
      )}
      {!isSpeaking && !isListening && !isAILoading && (
        <div className="flex items-center gap-2 text-gray-500 text-sm">
          <span>Waiting for you to speak...</span>
        </div>
      )}
    </div>
  );
}

function IdleState({ isConfigured, onStartCall, onOpenSettings }: {
  isConfigured: boolean;
  onStartCall: () => void;
  onOpenSettings: () => void;
}) {
  return (
    <>
      <p className="text-gray-400 text-sm mb-8 text-center">
        {isConfigured 
          ? 'Your AI agent is ready. Start a voice conversation.'
          : 'Please configure your OpenAI API key to start.'
        }
      </p>
      
      <button
        onClick={onStartCall}
        disabled={!isConfigured}
        className={`w-24 h-24 rounded-full flex items-center justify-center transition-all duration-300 shadow-lg ${
          isConfigured 
            ? 'bg-emerald-500 hover:bg-emerald-600 hover:scale-105 shadow-emerald-500/30' 
            : 'bg-gray-700 cursor-not-allowed'
        }`}
      >
        <PhoneCall className="w-10 h-10 text-white" />
      </button>
      
      <span className="text-gray-400 text-sm mt-5 font-medium">
        {isConfigured ? 'Start Call' : 'API Key Required'}
      </span>
      
      {!isConfigured && (
        <Button 
          variant="outline" 
          className="mt-4 border-[#333] text-white hover:bg-[#1a1a1a]"
          onClick={onOpenSettings}
        >
          <Key className="w-4 h-4 mr-2" />
          Add API Key
        </Button>
      )}
    </>
  );
}

function ConnectingState() {
  return (
    <>
      <p className="text-gray-400 text-sm mb-8">Connecting to AI...</p>
      <div className="relative">
        <div className="absolute inset-0 rounded-full bg-emerald-500/30 animate-ping" />
        <div className="absolute inset-0 rounded-full bg-emerald-500/20 animate-pulse" />
        <div className="w-24 h-24 rounded-full bg-emerald-500 flex items-center justify-center relative">
          <Loader2 className="w-10 h-10 text-white animate-spin" />
        </div>
      </div>
    </>
  );
}

function ConnectedState({
  isSpeaking,
  isListening,
  isMuted,
  isAILoading,
  interimTranscript,
  onToggleMute,
  onEndCall,
  onToggleListening
}: {
  isSpeaking: boolean;
  isListening: boolean;
  isMuted: boolean;
  isAILoading: boolean;
  interimTranscript: string;
  onToggleMute: () => void;
  onEndCall: () => void;
  onToggleListening: () => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    let time = 0;

    const animate = () => {
      time += 0.1;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const bars = 12;
      const barWidth = 6;
      const gap = 4;
      const centerX = canvas.width / 2;
      const centerY = canvas.height / 2;

      for (let i = 0; i < bars; i++) {
        const x = centerX - ((bars * (barWidth + gap)) / 2) + i * (barWidth + gap);
        
        let height = 10;
        if (isSpeaking || isListening) {
          const wave = Math.sin(time + i * 0.5) * 20 + Math.sin(time * 2 + i * 0.3) * 10;
          height = 20 + Math.abs(wave) + Math.random() * 15;
        }

        const color = isSpeaking ? '#10b981' : isListening ? '#3b82f6' : '#374151';
        
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.roundRect(x, centerY - height / 2, barWidth, height, 3);
        ctx.fill();
      }

      animationId = requestAnimationFrame(animate);
    };

    animate();

    return () => cancelAnimationFrame(animationId);
  }, [isSpeaking, isListening]);

  return (
    <>
      {/* Visualizer */}
      <div className="mb-8">
        <canvas 
          ref={canvasRef} 
          width={140} 
          height={80} 
          className="rounded-lg"
        />
      </div>

      {/* Controls */}
      <div className="flex items-center gap-4">
        {/* Mute Button */}
        <ControlButton
          onClick={onToggleMute}
          isActive={isMuted}
          activeColor="red"
          icon={isMuted ? VolumeX : Volume2}
          label={isMuted ? 'Unmute' : 'Mute'}
        />

        {/* End Call Button */}
        <button
          onClick={onEndCall}
          className="w-20 h-20 rounded-full bg-red-500 hover:bg-red-600 flex items-center justify-center transition-all duration-300 shadow-lg shadow-red-500/30 hover:scale-105"
        >
          <PhoneOff className="w-8 h-8 text-white" />
        </button>

        {/* Mic Button */}
        <ControlButton
          onClick={onToggleListening}
          isActive={isListening}
          disabled={isSpeaking || isAILoading}
          activeColor="blue"
          icon={isListening ? Mic : MicOff}
          label={isListening ? 'Stop' : 'Talk'}
        />
      </div>

      {/* Live Transcript */}
      {interimTranscript && (
        <div className="mt-6 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg px-4 py-3 max-w-sm w-full animate-fade-in">
          <p className="text-gray-500 text-xs mb-1">You said:</p>
          <p className="text-white text-sm">{interimTranscript}</p>
        </div>
      )}
    </>
  );
}

function ControlButton({
  onClick,
  isActive,
  disabled = false,
  activeColor,
  icon: Icon,
  label
}: {
  onClick: () => void;
  isActive: boolean;
  disabled?: boolean;
  activeColor: 'red' | 'blue';
  icon: React.ElementType;
  label: string;
}) {
  const colorClass = activeColor === 'red' 
    ? 'bg-red-500/20 text-red-400 border-red-500/50' 
    : 'bg-blue-500 text-white';

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`w-12 h-12 rounded-full flex items-center justify-center transition-all duration-200 ${
        isActive 
          ? colorClass 
          : 'bg-[#2a2a2a] text-gray-400 hover:bg-[#3a3a3a]'
      } ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
      title={label}
    >
      <Icon className="w-5 h-5" />
    </button>
  );
}

function EndedState() {
  return (
    <>
      <p className="text-gray-400 text-sm mb-8">Call ended</p>
      <div className="w-24 h-24 rounded-full bg-gray-700 flex items-center justify-center">
        <Loader2 className="w-10 h-10 text-gray-400 animate-spin" />
      </div>
    </>
  );
}
