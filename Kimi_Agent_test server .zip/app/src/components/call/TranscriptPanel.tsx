import { useEffect, useRef } from 'react';
import { MessageSquare, Volume2, Mic, Loader2, FunctionSquare, ExternalLink } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import type { Message, CallStatus } from '@/types';

interface TranscriptPanelProps {
  messages: Message[];
  callStatus: CallStatus;
  isSpeaking: boolean;
}

export function TranscriptPanel({ messages, callStatus, isSpeaking }: TranscriptPanelProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (bottomRef.current) {
      bottomRef.current.scrollIntoView({ behavior: 'smooth', block: 'end' });
    }
  }, [messages]);

  return (
    <div className="w-[400px] bg-[#0a0a0a] border-l border-[#1f1f1f] flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b border-[#1f1f1f] flex items-center justify-between bg-[#0a0a0a]">
        <div className="flex items-center gap-2">
          <MessageSquare className="w-4 h-4 text-gray-400" />
          <span className="text-gray-200 text-sm font-medium">Conversation</span>
        </div>
        <StatusBadge callStatus={callStatus} />
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1" ref={scrollRef}>
        <div className="p-4 space-y-3">
          {messages.length === 0 ? (
            <EmptyState />
          ) : (
            messages.map((msg, index) => (
              <MessageBubble 
                key={msg.id} 
                message={msg} 
                isSpeaking={isSpeaking && index === messages.length - 1}
              />
            ))
          )}
          <div ref={bottomRef} />
        </div>
      </ScrollArea>

      {/* Footer */}
      <div className="p-3 border-t border-[#1f1f1f] bg-[#0a0a0a]">
        <div className="flex items-center justify-between">
          <span className="text-xs text-gray-500">
            {messages.length} {messages.length === 1 ? 'message' : 'messages'}
          </span>
          {callStatus === 'connected' && (
            <div className="flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-xs text-emerald-400">Live</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function StatusBadge({ callStatus }: { callStatus: CallStatus }) {
  if (callStatus === 'connected') {
    return (
      <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30 text-xs">
        <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 mr-1.5 animate-pulse" />
        Live
      </Badge>
    );
  }
  return (
    <Badge variant="outline" className="text-gray-500 border-gray-700 text-xs">
      Offline
    </Badge>
  );
}

function EmptyState() {
  return (
    <div className="flex flex-col items-center justify-center py-12 text-gray-500">
      <div className="w-16 h-16 rounded-full bg-[#1a1a1a] flex items-center justify-center mb-4">
        <MessageSquare className="w-8 h-8 opacity-30" />
      </div>
      <p className="text-sm">No messages yet</p>
      <p className="text-xs mt-1 text-gray-600">Start a call to begin the conversation</p>
    </div>
  );
}

interface MessageBubbleProps {
  message: Message;
  isSpeaking: boolean;
}

function MessageBubble({ message, isSpeaking }: MessageBubbleProps) {
  switch (message.type) {
    case 'agent':
      return (
        <div className="flex flex-col items-start animate-fade-in">
          <div className="flex items-center gap-2 mb-1">
            <div className="w-5 h-5 rounded-full bg-emerald-500/20 flex items-center justify-center">
              <Volume2 className="w-3 h-3 text-emerald-400" />
            </div>
            <span className="text-xs text-gray-500">AI Agent</span>
          </div>
          <div 
            className={`bg-[#1a1a1a] text-gray-200 px-4 py-3 rounded-2xl rounded-tl-sm max-w-[90%] text-sm leading-relaxed border border-[#2a2a2a] ${
              isSpeaking ? 'ring-2 ring-emerald-500/30' : ''
            }`}
          >
            {message.content}
          </div>
          {isSpeaking && (
            <span className="text-[10px] text-emerald-400 mt-1 ml-1 flex items-center gap-1">
              <span className="w-1 h-1 rounded-full bg-emerald-400 animate-pulse" />
              speaking
            </span>
          )}
        </div>
      );

    case 'user':
      return (
        <div className="flex flex-col items-end animate-fade-in">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs text-gray-500">You</span>
            <div className="w-5 h-5 rounded-full bg-blue-500/20 flex items-center justify-center">
              <Mic className="w-3 h-3 text-blue-400" />
            </div>
          </div>
          <div className="bg-[#2a2a2a] text-gray-100 px-4 py-3 rounded-2xl rounded-tr-sm max-w-[90%] text-sm border border-[#3a3a3a]">
            {message.content}
          </div>
        </div>
      );

    case 'function':
      return (
        <div className="flex flex-col items-start animate-fade-in">
          <div className="flex items-center gap-2 bg-amber-500/10 border border-amber-500/30 text-amber-400 px-3 py-2 rounded-full text-xs">
            <FunctionSquare className="w-3.5 h-3.5" />
            <span>{message.content}</span>
          </div>
          {message.functionName && (
            <div className="mt-1 ml-1 flex items-center gap-2 bg-blue-500/10 border border-blue-500/30 text-blue-400 px-3 py-1.5 rounded-full text-xs">
              <ExternalLink className="w-3 h-3" />
              <span>{message.functionName}</span>
            </div>
          )}
        </div>
      );

    case 'reasoning':
      return (
        <div className="flex items-center justify-center gap-2 py-2 animate-fade-in">
          <Loader2 className="w-3.5 h-3.5 text-purple-400 animate-spin" />
          <span className="text-purple-400 text-xs">{message.content}</span>
        </div>
      );

    case 'system':
      return (
        <div className="flex justify-center py-2 animate-fade-in">
          <span className="text-amber-400 text-xs bg-amber-500/10 border border-amber-500/30 px-4 py-2 rounded-full text-center">
            {message.content}
          </span>
        </div>
      );

    default:
      return null;
  }
}
