import { 
  LayoutDashboard, 
  Users, 
  Megaphone, 
  Brain, 
  Phone, 
  Wrench, 
  FileText, 
  Code, 
  BarChart3, 
  FileBarChart,
  Key,
  Edit3
} from 'lucide-react';
import { Button } from '@/components/ui/button';

interface SidebarProps {
  activeView: string;
  onViewChange: (view: string) => void;
  onOpenSettings: () => void;
  onOpenPromptEditor: () => void;
}

const buildNavItems = [
  { icon: LayoutDashboard, label: 'Overview', id: 'overview' },
  { icon: Users, label: 'Voice Agents', id: 'call' },
  { icon: Megaphone, label: 'Campaigns', id: 'campaigns' },
  { icon: Brain, label: 'Models', id: 'models' },
  { icon: Phone, label: 'Telephony', id: 'telephony' },
  { icon: Wrench, label: 'Tools', id: 'tools' },
  { icon: FileText, label: 'Files', id: 'files' },
  { icon: Code, label: 'Developers', id: 'developers' },
];

const observeNavItems = [
  { icon: BarChart3, label: 'Usage', id: 'usage' },
  { icon: FileBarChart, label: 'Reports', id: 'reports' },
];

export function Sidebar({ activeView, onViewChange, onOpenSettings, onOpenPromptEditor }: SidebarProps) {
  return (
    <div className="w-[260px] bg-[#0a0a0a] border-r border-[#1f1f1f] flex flex-col h-full">
      {/* Logo */}
      <div className="p-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-500 to-blue-500 flex items-center justify-center">
            <Phone className="w-4 h-4 text-white" />
          </div>
          <div>
            <span className="text-white font-semibold text-lg">Workflow</span>
            <span className="text-gray-500 text-xs ml-2">v2.0</span>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto pt-2">

        {/* Overview */}
        <div className="px-3 py-1">
          <NavButton 
            icon={LayoutDashboard} 
            label="Overview" 
            isActive={activeView === 'overview'}
            onClick={() => onViewChange('overview')}
          />
        </div>

        {/* BUILD Section */}
        <SectionHeader title="Build" />
        <div className="px-2 space-y-0.5">
          {buildNavItems.slice(1).map((item) => (
            <NavButton
              key={item.id}
              icon={item.icon}
              label={item.label}
              isActive={activeView === item.id}
              onClick={() => onViewChange(item.id)}
            />
          ))}
        </div>

        {/* OBSERVE Section */}
        <SectionHeader title="Observe" />
        <div className="px-2 space-y-0.5">
          {observeNavItems.map((item) => (
            <NavButton
              key={item.id}
              icon={item.icon}
              label={item.label}
              isActive={activeView === item.id}
              onClick={() => onViewChange(item.id)}
            />
          ))}
        </div>

        {/* Settings Section */}
        <SectionHeader title="Configuration" />
        <div className="px-2 space-y-0.5">
          <NavButton
            icon={Key}
            label="API Keys"
            isActive={false}
            onClick={onOpenSettings}
          />
          <NavButton
            icon={Edit3}
            label="Edit Prompt"
            isActive={false}
            onClick={onOpenPromptEditor}
          />
        </div>
      </div>

      {/* Footer */}
      <div className="p-3 border-t border-[#1f1f1f]">
        <div className="flex items-center gap-2 text-gray-500 text-xs">
          <div className="w-2 h-2 rounded-full bg-emerald-500" />
          <span>System Online</span>
        </div>
      </div>
    </div>
  );
}

function SectionHeader({ title }: { title: string }) {
  return (
    <div className="px-4 py-2 mt-3">
      <span className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider">
        {title}
      </span>
    </div>
  );
}

interface NavButtonProps {
  icon: React.ElementType;
  label: string;
  isActive: boolean;
  onClick: () => void;
}

function NavButton({ icon: Icon, label, isActive, onClick }: NavButtonProps) {
  return (
    <Button
      variant="ghost"
      onClick={onClick}
      className={`w-full justify-start gap-3 text-sm h-9 transition-all duration-200 ${
        isActive 
          ? 'bg-[#1a1a1a] text-white font-medium' 
          : 'text-gray-400 hover:text-white hover:bg-[#1a1a1a]'
      }`}
    >
      <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-400' : ''}`} />
      <span>{label}</span>
      {isActive && <div className="ml-auto w-1 h-1 rounded-full bg-emerald-400" />}
    </Button>
  );
}
