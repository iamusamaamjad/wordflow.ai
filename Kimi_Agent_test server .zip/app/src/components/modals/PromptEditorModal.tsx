import { useState } from 'react';
import { X, Edit3, Check, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

interface PromptEditorModalProps {
  isOpen: boolean;
  prompt: string;
  defaultPrompt: string;
  onClose: () => void;
  onSave: (prompt: string) => void;
}

export function PromptEditorModal({ isOpen, prompt, defaultPrompt, onClose, onSave }: PromptEditorModalProps) {
  const [tempPrompt, setTempPrompt] = useState(prompt);

  if (!isOpen) return null;

  const handleSave = () => {
    onSave(tempPrompt);
    onClose();
  };

  const handleReset = () => {
    setTempPrompt(defaultPrompt);
  };

  const charCount = tempPrompt.length;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 animate-fade-in">
      <Card className="bg-[#111111] border-[#222222] w-full max-w-2xl mx-4 overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-5 border-b border-[#222222] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center">
              <Edit3 className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <h3 className="text-white text-lg font-medium">Edit Agent Prompt</h3>
              <p className="text-gray-500 text-xs">Customize how your AI agent behaves</p>
            </div>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose} className="text-gray-400 hover:text-white">
            <X className="w-5 h-5" />
          </Button>
        </div>

        {/* Content */}
        <div className="p-5 flex-1 overflow-hidden flex flex-col">
          <div className="mb-3 flex items-center justify-between">
            <p className="text-gray-400 text-sm">
              This system prompt guides how your AI agent responds to conversations.
            </p>
            <span className={`text-xs ${charCount > 2000 ? 'text-red-400' : 'text-gray-500'}`}>
              {charCount} chars
            </span>
          </div>
          
          <textarea
            value={tempPrompt}
            onChange={(e) => setTempPrompt(e.target.value)}
            className="flex-1 min-h-[300px] bg-[#1a1a1a] border border-[#333333] rounded-lg px-4 py-3 text-white text-sm resize-none focus:outline-none focus:border-purple-500/50 focus:ring-1 focus:ring-purple-500/50 transition-all leading-relaxed"
            placeholder="Enter your system prompt here..."
          />

          {/* Tips */}
          <div className="mt-4 bg-[#1a1a1a] rounded-lg p-4 border border-[#333333]">
            <p className="text-gray-500 text-xs font-medium mb-2">Tips for better responses:</p>
            <ul className="text-gray-500 text-xs space-y-1 list-disc list-inside">
              <li>Be specific about the agent&apos;s role and personality</li>
              <li>Keep responses concise for voice conversation</li>
              <li>Include examples of how to handle common questions</li>
              <li>Specify what the agent should NOT do</li>
            </ul>
          </div>
        </div>

        {/* Footer */}
        <div className="p-5 border-t border-[#222222] flex gap-3">
          <Button 
            variant="outline" 
            className="border-[#333333] text-gray-400 hover:bg-[#1a1a1a] hover:text-white"
            onClick={handleReset}
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Reset to Default
          </Button>
          <div className="flex-1" />
          <Button 
            variant="outline" 
            className="border-[#333333] text-gray-400 hover:bg-[#1a1a1a] hover:text-white"
            onClick={onClose}
          >
            Cancel
          </Button>
          <Button 
            className="bg-white text-black hover:bg-gray-100"
            onClick={handleSave}
          >
            <Check className="w-4 h-4 mr-2" />
            Save Prompt
          </Button>
        </div>
      </Card>
    </div>
  );
}
