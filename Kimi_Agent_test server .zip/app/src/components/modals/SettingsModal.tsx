import { useState } from 'react';
import { X, Key, Check, AlertCircle, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

interface SettingsModalProps {
  isOpen: boolean;
  apiKey: string;
  onClose: () => void;
  onSave: (key: string) => void;
}

export function SettingsModal({ isOpen, apiKey, onClose, onSave }: SettingsModalProps) {
  const [tempKey, setTempKey] = useState(apiKey);
  const [showKey, setShowKey] = useState(false);

  if (!isOpen) return null;

  const isValid = tempKey.startsWith('sk-') && tempKey.length > 20;

  const handleSave = () => {
    onSave(tempKey);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 animate-fade-in">
      <Card className="bg-[#111111] border-[#222222] w-full max-w-lg mx-4 overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-[#222222] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
              <Key className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <h3 className="text-white text-lg font-medium">API Configuration</h3>
              <p className="text-gray-500 text-xs">Configure your OpenAI API key</p>
            </div>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose} className="text-gray-400 hover:text-white">
            <X className="w-5 h-5" />
          </Button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-5">
          {/* API Key Input */}
          <div>
            <label className="text-gray-400 text-sm block mb-2">OpenAI API Key</label>
            <div className="relative">
              <input 
                type={showKey ? 'text' : 'password'}
                value={tempKey}
                onChange={(e) => setTempKey(e.target.value)}
                placeholder="sk-..."
                className="w-full bg-[#1a1a1a] border border-[#333333] rounded-lg px-4 py-3 text-white text-sm pr-24 focus:outline-none focus:border-blue-500/50 focus:ring-1 focus:ring-blue-500/50 transition-all"
              />
              <button
                onClick={() => setShowKey(!showKey)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 text-xs hover:text-gray-300"
              >
                {showKey ? 'Hide' : 'Show'}
              </button>
            </div>
            <div className="flex items-center gap-1 mt-2">
              <ExternalLink className="w-3 h-3 text-gray-500" />
              <a 
                href="https://platform.openai.com/api-keys" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-gray-500 text-xs hover:text-blue-400 transition-colors"
              >
                Get your API key from OpenAI
              </a>
            </div>
          </div>

          {/* Status */}
          <div className={`rounded-lg p-4 border ${
            isValid 
              ? 'bg-emerald-500/10 border-emerald-500/30' 
              : tempKey 
                ? 'bg-amber-500/10 border-amber-500/30' 
                : 'bg-[#1a1a1a] border-[#333333]'
          }`}>
            <div className="flex items-center gap-3">
              {isValid ? (
                <>
                  <div className="w-8 h-8 rounded-full bg-emerald-500/20 flex items-center justify-center">
                    <Check className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div>
                    <p className="text-emerald-400 text-sm font-medium">API Key Valid</p>
                    <p className="text-emerald-400/70 text-xs">Your API key is configured correctly</p>
                  </div>
                </>
              ) : tempKey ? (
                <>
                  <div className="w-8 h-8 rounded-full bg-amber-500/20 flex items-center justify-center">
                    <AlertCircle className="w-4 h-4 text-amber-400" />
                  </div>
                  <div>
                    <p className="text-amber-400 text-sm font-medium">Invalid API Key</p>
                    <p className="text-amber-400/70 text-xs">API key should start with &quot;sk-&quot;</p>
                  </div>
                </>
              ) : (
                <>
                  <div className="w-8 h-8 rounded-full bg-gray-700 flex items-center justify-center">
                    <Key className="w-4 h-4 text-gray-500" />
                  </div>
                  <div>
                    <p className="text-gray-400 text-sm font-medium">Not Configured</p>
                    <p className="text-gray-500 text-xs">Add your API key to enable AI</p>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Info */}
          <div className="bg-[#1a1a1a] rounded-lg p-4 border border-[#333333]">
            <p className="text-gray-500 text-xs leading-relaxed">
              Your API key is stored locally in your browser and is never sent to our servers. 
              It is only used to make requests directly to OpenAI&apos;s API.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-5 border-t border-[#222222] flex gap-3">
          <Button 
            variant="outline" 
            className="flex-1 border-[#333333] text-gray-400 hover:bg-[#1a1a1a] hover:text-white"
            onClick={onClose}
          >
            Cancel
          </Button>
          <Button 
            className="flex-1 bg-white text-black hover:bg-gray-100"
            onClick={handleSave}
            disabled={!isValid && tempKey !== ''}
          >
            <Check className="w-4 h-4 mr-2" />
            Save Settings
          </Button>
        </div>
      </Card>
    </div>
  );
}
