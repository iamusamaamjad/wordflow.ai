import { useState, useCallback, useRef } from 'react';
import type { ConversationMessage } from '@/types';

const DEFAULT_SYSTEM_PROMPT = `You are a helpful AI voice assistant. Be concise and friendly in your responses. Keep answers short (1-2 sentences) for voice conversation.`;

export function useOpenAI() {
  const [apiKey, setApiKey] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('openai_api_key') || '';
    }
    return '';
  });
  
  const [systemPrompt, setSystemPrompt] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('openai_system_prompt') || DEFAULT_SYSTEM_PROMPT;
    }
    return DEFAULT_SYSTEM_PROMPT;
  });
  
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const conversationHistoryRef = useRef<ConversationMessage[]>([]);

  const saveApiKey = useCallback((key: string) => {
    setApiKey(key);
    localStorage.setItem('openai_api_key', key);
  }, []);

  const saveSystemPrompt = useCallback((prompt: string) => {
    setSystemPrompt(prompt);
    localStorage.setItem('openai_system_prompt', prompt);
  }, []);

  const resetConversation = useCallback(() => {
    conversationHistoryRef.current = [];
  }, []);

  const sendMessage = useCallback(async (userMessage: string): Promise<string> => {
    if (!apiKey || !apiKey.startsWith('sk-')) {
      return 'Please add a valid OpenAI API key in Settings. Get one from platform.openai.com';
    }

    setIsLoading(true);
    setError(null);

    try {
      conversationHistoryRef.current.push({ role: 'user', content: userMessage });

      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          model: 'gpt-3.5-turbo',
          messages: [
            { role: 'system', content: systemPrompt },
            ...conversationHistoryRef.current.slice(-10)
          ],
          temperature: 0.7,
          max_tokens: 150
        })
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        if (response.status === 401) {
          throw new Error('Invalid API key. Please check your OpenAI API key.');
        }
        throw new Error(errorData.error?.message || `API Error: ${response.status}`);
      }

      const data = await response.json();
      const aiMessage = data.choices?.[0]?.message?.content?.trim() || "I'm sorry, I didn't understand that.";
      
      conversationHistoryRef.current.push({ role: 'assistant', content: aiMessage });

      setIsLoading(false);
      return aiMessage;
    } catch (err) {
      setIsLoading(false);
      const errorMsg = err instanceof Error ? err.message : 'Unknown error';
      setError(errorMsg);
      return `Sorry, I encountered an error: ${errorMsg}`;
    }
  }, [apiKey, systemPrompt]);

  const isConfigured = Boolean(apiKey && apiKey.startsWith('sk-'));

  return {
    apiKey,
    systemPrompt,
    isLoading,
    error,
    isConfigured,
    sendMessage,
    saveApiKey,
    saveSystemPrompt,
    resetConversation
  };
}
