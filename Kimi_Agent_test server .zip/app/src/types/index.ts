export type CallStatus = 'idle' | 'connecting' | 'connected' | 'ended';
export type MessageType = 'agent' | 'user' | 'function' | 'reasoning' | 'system';

export interface Message {
  id: string;
  type: MessageType;
  content: string;
  functionName?: string;
  timestamp: number;
}

export interface Tool {
  id: string;
  name: string;
  url: string;
  description: string;
  method: 'GET' | 'POST';
  headers?: Record<string, string>;
}

export interface NavItem {
  icon: React.ElementType;
  label: string;
  id: string;
}

export interface ConversationMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}
