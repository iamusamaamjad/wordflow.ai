import { useState, useCallback, useEffect } from 'react';
import { PhoneCall, Wrench, Zap, Brain } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Sidebar } from '@/components/sidebar/Sidebar';
import { CallPanel } from '@/components/call/CallPanel';
import { TranscriptPanel } from '@/components/call/TranscriptPanel';
import { SettingsModal } from '@/components/modals/SettingsModal';
import { PromptEditorModal } from '@/components/modals/PromptEditorModal';
import { ModelsPage } from '@/components/models/ModelsPage';
import { useSpeechRecognition, useSpeechSynthesis } from '@/hooks/useSpeech';
import { useOpenAI } from '@/hooks/useOpenAI';
import type { Message, CallStatus, Tool } from '@/types';

const DEFAULT_SYSTEM_PROMPT = `You are a helpful AI voice assistant for customer service.

Your personality:
- Friendly, professional, and patient
- Speak naturally as if in a real conversation
- Keep responses brief (1-2 sentences) for voice

How to respond:
- Greet users warmly
- Ask clarifying questions when needed
- Be helpful but concise
- If you don't know something, say so honestly

Remember: This is a voice conversation, so keep it natural and conversational.`;

// Coming Soon Page Component
function ComingSoonPage({ title, description }: { title: string; description: string }) {
  return (
    <div className="flex-1 bg-black flex items-center justify-center p-8">
      <Card className="bg-[#111111] border-[#222222] p-12 max-w-md text-center">
        <div className="w-20 h-20 rounded-full bg-[#1a1a1a] flex items-center justify-center mx-auto mb-6">
          <Zap className="w-10 h-10 text-gray-600" />
        </div>
        <h2 className="text-2xl font-semibold text-white mb-2">{title}</h2>
        <p className="text-gray-400 mb-4">{description}</p>
        <p className="text-gray-500 text-sm">This feature is coming soon. Stay tuned!</p>
      </Card>
    </div>
  );
}

// Overview Page
function OverviewPage({ onStartCall, isConfigured }: { onStartCall: () => void; isConfigured: boolean }) {
  return (
    <div className="flex-1 bg-black p-8 overflow-auto">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Hero */}
        <Card className="bg-gradient-to-br from-[#111111] to-[#1a1a1a] border-[#222222] p-8">
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-3xl font-bold text-white mb-3">Welcome to Workflow AI</h1>
              <p className="text-gray-400 text-lg mb-6 max-w-xl">
                Build powerful AI voice agents with real-time speech recognition and natural language understanding.
              </p>
              <div className="flex gap-3">
                {isConfigured ? (
                  <Button 
                    className="bg-emerald-500 hover:bg-emerald-600 text-white px-6"
                    onClick={onStartCall}
                  >
                    <PhoneCall className="w-4 h-4 mr-2" />
                    Start Voice Call
                  </Button>
                ) : (
                  <Button 
                    variant="outline"
                    className="border-amber-500/50 text-amber-400 hover:bg-amber-500/10"
                    disabled
                  >
                    Configure API Key First
                  </Button>
                )}
              </div>
            </div>
            <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-emerald-500 to-blue-500 flex items-center justify-center shadow-lg shadow-emerald-500/20">
              <PhoneCall className="w-12 h-12 text-white" />
            </div>
          </div>
        </Card>

        {/* Features */}
        <div className="grid grid-cols-3 gap-4">
          <FeatureCard 
            icon={PhoneCall}
            title="Voice Calls"
            description="Real-time voice conversations with AI"
            color="emerald"
          />
          <FeatureCard 
            icon={Brain}
            title="GPT Powered"
            description="Powered by OpenAI's latest models"
            color="purple"
          />
          <FeatureCard 
            icon={Wrench}
            title="Custom Tools"
            description="Connect your own APIs and services"
            color="blue"
          />
        </div>

        {/* Quick Setup */}
        <Card className="bg-[#111111] border-[#222222] p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Quick Setup Guide</h3>
          <div className="space-y-4">
            <SetupStep 
              number={1} 
              title="Add API Key" 
              description="Configure your OpenAI API key in Settings"
              isComplete={isConfigured}
            />
            <SetupStep 
              number={2} 
              title="Customize Prompt" 
              description="Edit how your AI agent behaves (optional)"
              isComplete={false}
            />
            <SetupStep 
              number={3} 
              title="Start Talking" 
              description="Begin a voice conversation with your AI"
              isComplete={false}
            />
          </div>
        </Card>
      </div>
    </div>
  );
}

function FeatureCard({ icon: Icon, title, description, color }: {
  icon: React.ElementType;
  title: string;
  description: string;
  color: 'emerald' | 'purple' | 'blue';
}) {
  const colors = {
    emerald: 'bg-emerald-500/20 text-emerald-400',
    purple: 'bg-purple-500/20 text-purple-400',
    blue: 'bg-blue-500/20 text-blue-400'
  };

  return (
    <Card className="bg-[#111111] border-[#222222] p-5 hover:border-[#333333] transition-colors">
      <div className={`w-12 h-12 rounded-xl ${colors[color]} flex items-center justify-center mb-4`}>
        <Icon className="w-6 h-6" />
      </div>
      <h3 className="text-white font-semibold mb-1">{title}</h3>
      <p className="text-gray-400 text-sm">{description}</p>
    </Card>
  );
}

function SetupStep({ number, title, description, isComplete }: {
  number: number;
  title: string;
  description: string;
  isComplete: boolean;
}) {
  return (
    <div className="flex items-start gap-4">
      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium flex-shrink-0 ${
        isComplete 
          ? 'bg-emerald-500/20 text-emerald-400' 
          : 'bg-[#1a1a1a] text-gray-500 border border-[#333333]'
      }`}>
        {isComplete ? '✓' : number}
      </div>
      <div>
        <h4 className={`font-medium ${isComplete ? 'text-emerald-400' : 'text-white'}`}>{title}</h4>
        <p className="text-gray-500 text-sm">{description}</p>
      </div>
    </div>
  );
}

// Tools Page
function ToolsPage({ tools, onAddTool, onEditTool, onDeleteTool }: {
  tools: Tool[];
  onAddTool: () => void;
  onEditTool: (tool: Tool) => void;
  onDeleteTool: (id: string) => void;
}) {
  return (
    <div className="flex-1 bg-black p-8 overflow-auto">
      <div className="max-w-5xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-white">Tools</h1>
            <p className="text-gray-400 text-sm">Configure API endpoints for your AI agent</p>
          </div>
          <Button 
            className="bg-white text-black hover:bg-gray-100"
            onClick={onAddTool}
          >
            <PhoneCall className="w-4 h-4 mr-2" />
            Add Tool
          </Button>
        </div>

        {tools.length === 0 ? (
          <Card className="bg-[#111111] border-[#222222] p-12 text-center">
            <Wrench className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <h3 className="text-white font-semibold mb-2">No Tools Yet</h3>
            <p className="text-gray-400 text-sm mb-4">Add tools to enable your AI agent to call external APIs</p>
            <Button 
              variant="outline"
              className="border-[#333333] text-white hover:bg-[#1a1a1a]"
              onClick={onAddTool}
            >
              Create Your First Tool
            </Button>
          </Card>
        ) : (
          <div className="grid gap-3">
            {tools.map((tool) => (
              <Card key={tool.id} className="bg-[#111111] border-[#222222] p-4 hover:border-[#333333] transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
                      <Wrench className="w-5 h-5 text-blue-400" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-white font-medium">{tool.name}</h3>
                        <span className="text-xs px-2 py-0.5 rounded-full bg-[#1a1a1a] text-gray-400 border border-[#333333]">
                          {tool.method}
                        </span>
                      </div>
                      <p className="text-gray-400 text-sm">{tool.url}</p>
                      <p className="text-gray-500 text-xs">{tool.description}</p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      variant="ghost" 
                      size="sm"
                      className="text-gray-400 hover:text-white"
                      onClick={() => onEditTool(tool)}
                    >
                      Edit
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      className="text-gray-400 hover:text-red-400"
                      onClick={() => onDeleteTool(tool.id)}
                    >
                      Delete
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// Tool Editor Modal
function ToolEditorModal({ isOpen, tool, onClose, onSave }: {
  isOpen: boolean;
  tool: Tool | null;
  onClose: () => void;
  onSave: (tool: Tool) => void;
}) {
  const [name, setName] = useState(tool?.name || '');
  const [url, setUrl] = useState(tool?.url || '');
  const [method, setMethod] = useState<'GET' | 'POST'>(tool?.method || 'POST');
  const [description, setDescription] = useState(tool?.description || '');

  if (!isOpen) return null;

  const handleSave = () => {
    if (!name || !url) return;
    onSave({
      id: tool?.id || Date.now().toString(),
      name,
      url,
      method,
      description
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50">
      <Card className="bg-[#111111] border-[#222222] w-full max-w-lg mx-4 p-6">
        <h3 className="text-white text-lg font-medium mb-4">
          {tool ? 'Edit Tool' : 'Create Tool'}
        </h3>
        
        <div className="space-y-4">
          <div>
            <label className="text-gray-400 text-sm block mb-2">Tool Name</label>
            <input 
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., find-booking"
              className="w-full bg-[#1a1a1a] border border-[#333333] rounded-lg px-4 py-2 text-white text-sm"
            />
          </div>

          <div>
            <label className="text-gray-400 text-sm block mb-2">API URL</label>
            <input 
              type="text"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://api.example.com/endpoint"
              className="w-full bg-[#1a1a1a] border border-[#333333] rounded-lg px-4 py-2 text-white text-sm"
            />
          </div>

          <div>
            <label className="text-gray-400 text-sm block mb-2">Method</label>
            <select
              value={method}
              onChange={(e) => setMethod(e.target.value as 'GET' | 'POST')}
              className="w-full bg-[#1a1a1a] border border-[#333333] rounded-lg px-4 py-2 text-white text-sm"
            >
              <option value="GET">GET</option>
              <option value="POST">POST</option>
            </select>
          </div>

          <div>
            <label className="text-gray-400 text-sm block mb-2">Description</label>
            <input 
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="What does this tool do?"
              className="w-full bg-[#1a1a1a] border border-[#333333] rounded-lg px-4 py-2 text-white text-sm"
            />
          </div>
        </div>

        <div className="flex gap-3 mt-6">
          <Button 
            variant="outline"
            className="flex-1 border-[#333333] text-gray-400"
            onClick={onClose}
          >
            Cancel
          </Button>
          <Button 
            className="flex-1 bg-white text-black"
            onClick={handleSave}
            disabled={!name || !url}
          >
            Save Tool
          </Button>
        </div>
      </Card>
    </div>
  );
}

// Main App
function App() {
  const [currentView, setCurrentView] = useState('overview');
  const [callStatus, setCallStatus] = useState<CallStatus>('idle');
  const [messages, setMessages] = useState<Message[]>([]);
  const [showSettings, setShowSettings] = useState(false);
  const [showPromptEditor, setShowPromptEditor] = useState(false);
  const [showToolEditor, setShowToolEditor] = useState(false);
  const [editingTool, setEditingTool] = useState<Tool | null>(null);
  const [tools, setTools] = useState<Tool[]>([]);

  const { 
    apiKey, 
    systemPrompt, 
    isLoading: isAILoading, 
    error: aiError,
    isConfigured,
    sendMessage,
    saveApiKey,
    saveSystemPrompt,
    resetConversation
  } = useOpenAI();

  const {
    isListening,
    transcript,
    interimTranscript,
    error: speechError,
    startListening,
    stopListening,
    resetTranscript
  } = useSpeechRecognition();

  const {
    isSpeaking,
    isMuted,
    speak,
    stop: stopSpeaking,
    toggleMute
  } = useSpeechSynthesis();

  // Handle user speech
  useEffect(() => {
    if (transcript && callStatus === 'connected') {
      handleUserMessage(transcript);
      resetTranscript();
    }
  }, [transcript, callStatus]);

  const addMessage = useCallback((type: Message['type'], content: string, functionName?: string) => {
    const newMessage: Message = {
      id: `${Date.now()}-${Math.random()}`,
      type,
      content,
      functionName,
      timestamp: Date.now()
    };
    setMessages(prev => [...prev, newMessage]);
  }, []);

  const handleUserMessage = async (message: string) => {
    stopListening();
    addMessage('user', message);
    
    const aiResponse = await sendMessage(message);
    addMessage('agent', aiResponse);
    
    await speak(aiResponse);
    
    // Restart listening after speaking
    if (callStatus === 'connected') {
      setTimeout(() => startListening(), 300);
    }
  };

  const handleStartCall = async () => {
    try {
      await navigator.mediaDevices.getUserMedia({ audio: true });
      
      setCallStatus('connecting');
      setMessages([]);
      resetTranscript();
      resetConversation();
      
      setTimeout(async () => {
        setCallStatus('connected');
        
        if (!isConfigured) {
          addMessage('system', 'Please add your OpenAI API key in Settings to start.');
          return;
        }
        
        const greeting = "Hello! How can I help you today?";
        addMessage('agent', greeting);
        await speak(greeting);
        
        startListening();
      }, 1500);
    } catch {
      addMessage('system', 'Please allow microphone access to use voice features.');
    }
  };

  const handleEndCall = () => {
    stopListening();
    stopSpeaking();
    setCallStatus('ended');
    
    setTimeout(() => {
      setCallStatus('idle');
      setMessages([]);
      resetTranscript();
      resetConversation();
    }, 2000);
  };

  const handleToggleListening = () => {
    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  };

  // Tool management
  const handleSaveTool = (tool: Tool) => {
    if (editingTool) {
      setTools(prev => prev.map(t => t.id === tool.id ? tool : t));
    } else {
      setTools(prev => [...prev, tool]);
    }
    setEditingTool(null);
  };

  const handleDeleteTool = (id: string) => {
    setTools(prev => prev.filter(t => t.id !== id));
  };

  // Render main content based on view
  const renderContent = () => {
    switch (currentView) {
      case 'call':
        return (
          <>
            <CallPanel
              callStatus={callStatus}
              isListening={isListening}
              isSpeaking={isSpeaking}
              isAILoading={isAILoading}
              isMuted={isMuted}
              isConfigured={isConfigured}
              interimTranscript={interimTranscript}
              error={aiError || speechError}
              onStartCall={handleStartCall}
              onEndCall={handleEndCall}
              onToggleMute={toggleMute}
              onToggleListening={handleToggleListening}
              onOpenSettings={() => setShowSettings(true)}
            />
            <TranscriptPanel 
              messages={messages} 
              callStatus={callStatus}
              isSpeaking={isSpeaking}
            />
          </>
        );
      
      case 'overview':
        return (
          <OverviewPage 
            onStartCall={() => setCurrentView('call')}
            isConfigured={isConfigured}
          />
        );
      
      case 'tools':
        return (
          <ToolsPage
            tools={tools}
            onAddTool={() => {
              setEditingTool(null);
              setShowToolEditor(true);
            }}
            onEditTool={(tool) => {
              setEditingTool(tool);
              setShowToolEditor(true);
            }}
            onDeleteTool={handleDeleteTool}
          />
        );
      
      case 'campaigns':
        return <ComingSoonPage title="Campaigns" description="Manage bulk voice campaigns" />;
      case 'models':
        return <ModelsPage apiKey={apiKey} />;
      case 'telephony':
        return <ComingSoonPage title="Telephony" description="Configure phone providers" />;
      case 'files':
        return <ComingSoonPage title="Files" description="Manage knowledge base files" />;
      case 'developers':
        return <ComingSoonPage title="Developers" description="API keys and documentation" />;
      case 'usage':
        return <ComingSoonPage title="Usage" description="View usage statistics" />;
      case 'reports':
        return <ComingSoonPage title="Reports" description="Generate call reports" />;
      
      default:
        return <OverviewPage onStartCall={() => setCurrentView('call')} isConfigured={isConfigured} />;
    }
  };

  return (
    <div className="h-screen w-screen bg-black flex overflow-hidden">
      <Sidebar
        activeView={currentView}
        onViewChange={setCurrentView}
        onOpenSettings={() => setShowSettings(true)}
        onOpenPromptEditor={() => setShowPromptEditor(true)}
      />
      
      {renderContent()}

      <SettingsModal
        isOpen={showSettings}
        apiKey={apiKey}
        onClose={() => setShowSettings(false)}
        onSave={saveApiKey}
      />

      <PromptEditorModal
        isOpen={showPromptEditor}
        prompt={systemPrompt}
        defaultPrompt={DEFAULT_SYSTEM_PROMPT}
        onClose={() => setShowPromptEditor(false)}
        onSave={saveSystemPrompt}
      />

      <ToolEditorModal
        isOpen={showToolEditor}
        tool={editingTool}
        onClose={() => {
          setShowToolEditor(false);
          setEditingTool(null);
        }}
        onSave={handleSaveTool}
      />
    </div>
  );
}

export default App;
